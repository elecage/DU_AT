"""Shared 2D geometry for the Sofle Choc one-hand book case (KiCad PCB frame, mm, y down)."""
import re, math, json
from shapely.geometry import LineString, Polygon, Point, box
from shapely.ops import polygonize, unary_union
from shapely import affinity

PCB_FILE = '/root/sofle/Sofle_Choc/PCB/SofleKeyboard.kicad_pcb'
PLATE_FILE = '/root/sofle/Sofle_Choc/Case/PCBTop/SofleKeyboardTopPlate.kicad_pcb'
DX, DY = 0.995, 1.445

def edge_polys(t, shift=(0, 0)):
    segs = []
    for m in re.finditer(r'\(gr_line \(start ([-\d.]+) ([-\d.]+)\) \(end ([-\d.]+) ([-\d.]+)\)[^\n]*Edge\.Cuts', t):
        a = list(map(float, m.groups()))
        segs.append(LineString([(a[0] - shift[0], a[1] - shift[1]), (a[2] - shift[0], a[3] - shift[1])]))
    for m in re.finditer(r'\(gr_arc \(start ([-\d.]+) ([-\d.]+)\) \(end ([-\d.]+) ([-\d.]+)\) \(angle ([-\d.]+)\)[^\n]*Edge\.Cuts', t):
        cx, cy, ex, ey, ang = map(float, m.groups())
        r = math.hypot(ex - cx, ey - cy); a0 = math.atan2(ey - cy, ex - cx)
        segs.append(LineString([(cx + r * math.cos(a0 + math.radians(ang) * i / 12) - shift[0],
                                 cy + r * math.sin(a0 + math.radians(ang) * i / 12) - shift[1]) for i in range(13)]))
    return sorted(polygonize(unary_union(segs)), key=lambda p: -p.area)

tp, tt = open(PCB_FILE).read(), open(PLATE_FILE).read()
PCB = edge_polys(tp)[0]
_pp = edge_polys(tt, (DX, DY))
PLATE_OUTER = _pp[0]
ENCODER = [p for p in _pp[1:] if 150 < p.area < 250][0]

KEYS, HOLES = [], []
for m in re.finditer(r'\(module (\S+)[^\n]*\n\s*\(at ([-\d.]+) ([-\d.]+)(?: ([-\d.]+))?\)', tt):
    x, y, a = float(m.group(2)) - DX, float(m.group(3)) - DY, float(m.group(4) or 0) % 360
    if 'SW_Hole' in m.group(1): KEYS.append((x, y, a))
# fixing holes: use the PCB's own positions (Ø4.1 plated)
for m in re.finditer(r'\(module SofleKeyboard-footprint:HOLE_M2_TH[^\n]*\n\s*\(at ([-\d.]+) ([-\d.]+)', tp):
    HOLES.append((float(m.group(1)), float(m.group(2))))
CTRL_HOLES = [(float(m.group(1)), float(m.group(2))) for m in
              re.finditer(r'\(module SofleKeyboard-footprint:M2_HOLE_PCB[^\n]*\n\s*\(at ([-\d.]+) ([-\d.]+)', tp)]
THT = [tuple(v[:2]) for v in json.load(open('/tmp/claude-0/cad/tht.json'))]
TRRS = (88.0, 85.65)

def sq(x, y, a, s):
    return affinity.rotate(box(x - s / 2, y - s / 2, x + s / 2, y + s / 2), -a, origin=(x, y))

# ---- design parameters ----
CLR = 0.6            # pcb-to-pocket clearance
WALL = 4.2           # outer offset from pcb edge
TONGUE = 1.7
SKIRT_GAP = 0.2
SW_HOLE = 14.15      # printed switch hole (spec 14.0 + print shrink allowance)
KEEP = 16.0          # web keep-out around each switch (housing 15 + clearance)

POCKET = PCB.buffer(CLR, join_style=2)
OUTER = PCB.buffer(WALL, resolution=24)
OUTER_W = OUTER.buffer(-0.3, resolution=24)        # walls/cover sit 0.3 inside the page outline (avoids coincident faces)
TONGUE_OUT = POCKET.buffer(TONGUE, join_style=2)
SKIRT_IN = POCKET.buffer(TONGUE + SKIRT_GAP, join_style=2)

# controller opening = pocket area not covered by the original top plate
_d = POCKET.difference(PLATE_OUTER.buffer(0.3)).buffer(-2.0).buffer(2.0)
_n = [g for g in getattr(_d, 'geoms', [_d]) if g.area > 300]
NOTCH = max(_n, key=lambda g: g.area).buffer(2.5, join_style=2).intersection(POCKET)

# hinge line (inner edge of the right half) — page gets a straight strip out to it
X_HINGE = PCB.bounds[0] - WALL - 3.2            # just outside the thumb corner
PAGE_Y = (POCKET.bounds[1] + 8, POCKET.bounds[3] - 8)
STRIP = box(X_HINGE, PAGE_Y[0], OUTER.bounds[0] + 14, PAGE_Y[1])
PAGE = unary_union([OUTER, STRIP]).buffer(3, resolution=16).buffer(-3, resolution=16)
TRRS_SLOT = box(X_HINGE - 6, TRRS[1] - 4.6, TRRS[0] + 2, TRRS[1] + 4.6)

# heights (socket bottom = 0)
Z = dict(fb=-3.5, ft=-0.5, pcbB=1.85, pcbT=3.45, tongue=4.25, cB=4.8, cT=6.0, web=7.2)
HINGE_Z = Z['fb'] + 4.0
YC = (PAGE_Y[0] + PAGE_Y[1]) / 2

if __name__ == '__main__':
    print('pcb', [round(v, 2) for v in PCB.bounds], 'notch', round(NOTCH.area), [round(v, 1) for v in NOTCH.bounds])
    print('outer', [round(v, 2) for v in OUTER.bounds], 'page', [round(v, 2) for v in PAGE.bounds], 'x_hinge', round(X_HINGE, 2))
    print('keys', len(KEYS), 'holes', HOLES, 'ctrl', CTRL_HOLES, 'tht', len(THT))
