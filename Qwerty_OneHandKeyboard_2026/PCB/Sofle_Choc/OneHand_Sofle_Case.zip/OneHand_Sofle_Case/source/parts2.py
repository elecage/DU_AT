"""Book base (right half incl. spine half), centre prop, test coupon, and assembly previews.
Assembly frame: right hinge axis at X=+AX, left at -AX; CAD X = KiCad x shifted, CAD Y = -KiCad y."""
import math, sys
from shapely.geometry import box, Point
from shapely.ops import unary_union
from build123d import (Pos, Rot, Box, Cylinder, Location, Plane, mirror, export_stl, export_step, Text, extrude, Axis)
import geo as G
from parts1 import prism, cyl_z, cyl_y, bottom_case, top_cover, prop_bracket, KNUCKLES_SPINE, PROP_DX, PROP_W, Z

AX = 12.0                       # hinge axis distance from centre line
SHIFT = AX - G.X_HINGE          # KiCad x -> assembly X for the right half
HZ = G.HINGE_Z                  # 0.5
BASE_TOP, BASE_BOT, POCKET_FLOOR = Z['fb'], -12.5, -10.5
ZRT = -6.0                      # rack notch centre height (rod centre when seated)
PROP_L, ROD_R, NOTCH_R = 52.0, 1.5, 1.65
ANGLES = [10, 15, 20, 25, 30]
PIV = (PROP_DX, Z['fb'] - 3.0 - HZ)    # pivot relative to hinge axis (95, -7)

def pivot_at(deg):
    t = math.radians(deg)
    return (PIV[0] * math.cos(t) - PIV[1] * math.sin(t), HZ + PIV[0] * math.sin(t) + PIV[1] * math.cos(t))
def foot_at(deg):
    px, pz = pivot_at(deg)
    if deg == 0: return (px - PROP_L, pz)
    h = pz - ZRT
    return (px + math.sqrt(PROP_L ** 2 - h ** 2), ZRT)
NOTCHES = [foot_at(d)[0] for d in ANGLES]           # relative to hinge axis

YA, YB = G.OUTER.bounds[1] - 4, G.OUTER.bounds[3] + 4     # base extent in KiCad y
XO = AX + (G.OUTER.bounds[2] - G.X_HINGE) + 6              # outer end of the base (assembly X)
def ky(y): return y                                         # helper: KiCad y used directly with cyl_y/prism (they flip)

def base_right():
    # plate: square inner edge (joins the other half at X=0), rounded outer corners
    r = 14
    outline = unary_union([box(0, YA, XO, YB).buffer(-r).buffer(r), box(0, YA, 2 * r, YB)])
    b = prism(outline, BASE_BOT, BASE_TOP)
    # spine half
    spine = prism(box(0, YA + 4, AX - 4.2, YB - 4), BASE_TOP - 1.0, 2.0)
    for y0, y1 in KNUCKLES_SPINE:
        spine = spine + prism(box(AX - 6.0, y0, AX, y1), BASE_TOP - 1.0, HZ)
        spine = spine + cyl_y(AX, y0, y1, HZ, 3.9)
    b = b + spine
    b = b - cyl_y(AX, YA, YB, HZ, 1.65)
    # TRRS cable drop hole + underside channel to the other half
    b = b - cyl_z(4.0, G.TRRS[1], 4.5, BASE_BOT - 1, 3)
    b = b - prism(box(-1, G.TRRS[1] - 4.5, 8.5, G.TRRS[1] + 4.5), BASE_BOT - 1, BASE_BOT + 4.5)
    # pocket for prop, ears and the two side racks
    yc = G.YC
    pk = box(AX + PIV[0] - PROP_L - 6, yc - (PROP_W / 2 + 12.5), AX + max(NOTCHES) + 7, yc + (PROP_W / 2 + 12.5))
    b = b - prism(pk.buffer(3).buffer(-3), POCKET_FLOOR, BASE_TOP + 0.1)
    # side racks with half-round notches for the Ø3 rod ends
    rx0, rx1 = AX + min(NOTCHES) - 4, AX + max(NOTCHES) + 4
    for s in (-1, 1):
        ya_, yb_ = sorted((yc + s * (PROP_W / 2 + 1.5), yc + s * (PROP_W / 2 + 8.0)))
        b = b + prism(box(rx0, ya_, rx1, yb_), POCKET_FLOOR - 0.01, ZRT)
        for nx in NOTCHES:
            b = b - cyl_y(AX + nx, ya_ - 1, yb_ + 1, ZRT, NOTCH_R)
        # angle numbers engraved on the rack top faces (outer rack shows them to the user)
        for d, nx in zip(ANGLES, NOTCHES):
            try:
                txt = extrude(Text(str(d), font_size=3.2), amount=0.6)
                ty = -(yb_ + 3.2) if s > 0 else -(ya_ - 3.2)
                b = b - Pos(AX + nx, ty, POCKET_FLOOR - 0.5) * txt
            except Exception as e:
                pass
    # half-joint: 3 horizontal M3 bolts across X=0 with nut pockets from below
    for yj in (YA + 12, 115.0, YB - 12):
        b = b - Pos(10, -yj, -8.0) * Rot(0, 90, 0) * Cylinder(1.7, 24)
        b = b - Pos(16, -yj, -10.0) * Box(3.2, 6.4, 6.0)          # nut / head pocket, open below
    return b

def prop():
    L = PROP_L
    p = Pos(L / 2, 0, 0) * Box(L, PROP_W, 4)
    p = p - Pos(L / 2, 0, 0) * Box(L * 0.45, PROP_W * 0.55, 6)
    p = p + Rot(90, 0, 0) * Cylinder(2.8, PROP_W)                    # pivot tube
    p = p + Pos(L, 0, 0) * Rot(90, 0, 0) * Cylinder(2.9, PROP_W)     # foot tube (rod Ø3 inside)
    p = p - Rot(90, 0, 0) * Cylinder(1.65, PROP_W + 2)
    p = p - Pos(L, 0, 0) * Rot(90, 0, 0) * Cylinder(1.6, PROP_W + 2)
    return p

def coupon():
    """2x2 switch-hole test piece of the top cover (same 1.2 plate + web) + one stepped boss on a small floor."""
    pitch, n = 19.05, 2
    w = pitch * n + 6
    plate = Pos(w / 2 - 3, -(w / 2 - 3), (Z['cB'] + Z['cT']) / 2) * Box(w, w, Z['cT'] - Z['cB'])
    web = Pos(w / 2 - 3, -(w / 2 - 3), (Z['cT'] + Z['web']) / 2) * Box(w, w, Z['web'] - Z['cT'])
    for i in range(n):
        for j in range(n):
            cx, cy = pitch * (i + 0.5), pitch * (j + 0.5)
            plate = plate - Pos(cx, -cy, Z['cT']) * Box(G.SW_HOLE, G.SW_HOLE, 4)
            web = web - Pos(cx, -cy, Z['web']) * Box(G.KEEP, G.KEEP, 4)
    c = plate + web
    c = c - Pos(pitch, -pitch, Z['cT']) * Cylinder(1.15, 6)
    c = c - Pos(pitch, -pitch, Z['web']) * Cylinder(2.25, 2.0)
    return c

if __name__ == '__main__':
    out = sys.argv[1]
    print('notches (from hinge axis):', [round(v, 1) for v in NOTCHES])
    br = base_right(); pr = prop(); cp = coupon()
    bl = mirror(br, Plane.YZ)
    for name, part in (('R_base', br), ('L_base', bl), ('prop', pr), ('test_coupon', cp)):
        export_stl(part, f'{out}/{name}.stl', tolerance=0.02, angular_tolerance=0.2)
        export_step(part, f'{out}/{name}.step')
        print(name, round(part.volume))
    # ---- assembly previews (not for printing) ----
    bc, tc = bottom_case() + prop_bracket(), top_cover()
    def place_half(part, deg, left):
        # rotate the page about its hinge axis, then shift into assembly frame
        p = Pos(SHIFT, 0, 0) * part
        p = Pos(AX, 0, HZ) * Rot(0, -deg, 0) * Pos(-AX, 0, -HZ) * p
        return mirror(p, Plane.YZ) if left else p
    def place_prop(deg, left):
        px, pz = pivot_at(deg); fx, fz = foot_at(deg)
        ang = math.degrees(math.atan2(fz - pz, fx - px))
        p = Pos(AX + px, -G.YC, pz) * Rot(0, -ang, 0) * pr
        return mirror(p, Plane.YZ) if left else p
    import pcb_dummy as PD
    for tag, (dl, dr) in {'flat': (0, 0), 'tilt': (20, 20), 'mixed': (30, 10)}.items():
        export_stl(place_half(PD.d, dr, False) + place_half(PD.d, dl, True), f'{out}/asm_{tag}_pcb.stl', tolerance=0.08, angular_tolerance=0.4)
        export_stl(place_half(PD.CAPS, dr, False) + place_half(PD.CAPS, dl, True), f'{out}/asm_{tag}_caps.stl', tolerance=0.08, angular_tolerance=0.4)
    for tag, (dl, dr) in {'flat': (0, 0), 'tilt': (20, 20), 'mixed': (30, 10)}.items():
        for nm, part in (('base', br + bl),
                         ('caseR', place_half(bc, dr, False) + place_half(tc, dr, False)),
                         ('caseL', place_half(bc, dl, True) + place_half(tc, dl, True)),
                         ('props', place_prop(dr, False) + place_prop(dl, True))):
            export_stl(part, f'{out}/asm_{tag}_{nm}.stl', tolerance=0.05, angular_tolerance=0.3)
    print('done')
