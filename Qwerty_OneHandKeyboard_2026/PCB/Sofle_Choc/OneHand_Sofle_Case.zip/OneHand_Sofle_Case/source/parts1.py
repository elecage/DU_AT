"""Top cover + bottom case (book 'page') for the right half; left half = mirror."""
import math, sys
from shapely.geometry import Point, box, Polygon, MultiPolygon
from shapely.ops import unary_union
from build123d import (Face, Wire, Vector, Location, Pos, extrude, Cylinder, Box, Rot, Plane, mirror,
                       export_stl, export_step, Part, Compound, Axis)
import geo as G

def _wire(coords):
    pts = [Vector(x, -y, 0) for x, y in coords[:-1]]
    return Wire.make_polygon(pts, close=True)

def faces_of(poly):
    polys = poly.geoms if isinstance(poly, MultiPolygon) else [poly]
    out = []
    for p in polys:
        if p.is_empty or p.area < 0.05: continue
        p = p.simplify(0.02)
        out.append(Face(_wire(list(p.exterior.coords)), [_wire(list(i.coords)) for i in p.interiors]))
    return out

def prism(poly, z0, z1):
    parts = [extrude(f.moved(Location((0, 0, z0))), amount=z1 - z0, dir=(0, 0, 1)) for f in faces_of(poly)]
    res = parts[0]
    for q in parts[1:]: res = res + q
    return res

def cyl_z(x, y, r, z0, z1):
    return Pos(x, -y, (z0 + z1) / 2) * Cylinder(r, z1 - z0)

def cyl_y(x, y0, y1, z, r):
    # along KiCad y (CAD -Y)
    return Pos(x, -(y0 + y1) / 2, z) * Rot(90, 0, 0) * Cylinder(r, abs(y1 - y0))

Z = G.Z

# ------------------------------------------------------------------ bottom case / page
def bottom_case():
    floor = prism(G.PAGE, Z['fb'], Z['ft'])
    wall_out = prism(G.OUTER_W.difference(G.SKIRT_IN.buffer(-0.05)), Z['ft'] - 0.5, Z['pcbT'])
    tongue = prism(G.TONGUE_OUT.difference(G.POCKET), Z['ft'] - 0.5, Z['tongue'])
    body = floor + wall_out + tongue
    # clearance pockets under through-hole pins (headers, TRRS, encoder, reset)
    tht = unary_union([Point(x, y).buffer(1.8, 16) for x, y in G.THT]).buffer(0.6).intersection(G.POCKET)
    body = body - prism(tht, Z['ft'] - 1.6, Z['ft'] + 0.1)
    # stepped bosses through the Ø4.1 holes; the insert sits low in the Ø6 shoulder, screw comes down through the Ø3.8 pin
    for x, y in G.HOLES:
        body = body + cyl_z(x, y, 3.0, Z['fb'] + 0.6, Z['pcbB'])
        body = body + cyl_z(x, y, 1.9, Z['pcbB'] - 0.01, Z['cB'] - 0.05)
        body = body - cyl_z(x, y, 1.6, Z['fb'] - 0.1, Z['fb'] + 4.5)          # M2 heat-set insert, pressed in from below (Ø3.2 x 4)
        body = body - cyl_z(x, y, 1.15, Z['fb'] + 4.4, Z['cB'] + 0.1)        # screw clearance through the pin
    # controller-area posts at the reserved Ø2.2 holes (insert ready for the later ProMicro cover)
    for x, y in G.CTRL_HOLES:            # slim posts (TRRS pins / diode pads are close): Ø3.8, pilot Ø1.7 for M2 self-tapping
        body = body + cyl_z(x, y, 1.9, Z['fb'] + 0.6, Z['pcbB'])
        body = body - cyl_z(x, y, 0.85, Z['pcbB'] - 4.0, Z['pcbB'] + 0.1)
    # TRRS plug slot through the inner wall
    body = body - prism(G.TRRS_SLOT, Z['pcbB'] - 0.3, Z['web'] + 2)
    # hinge knuckles on the inner edge (pin Ø3 -> hole Ø3.3)
    for y0, y1 in KNUCKLES_PAGE:
        body = body + cyl_y(G.X_HINGE, y0, y1, G.HINGE_Z, 3.9)
    body = body - cyl_y(G.X_HINGE, G.PAGE_Y[0] - 5, G.PAGE_Y[1] + 5, G.HINGE_Z, 1.65)
    # clearance where the spine's knuckles sit
    for y0_, y1_ in KNUCKLES_SPINE:
        body = body - prism(box(G.X_HINGE - 8, y0_ - 0.4, G.X_HINGE + 4.7, y1_ + 0.4), Z['fb'] - 1, G.HINGE_Z + 4.8)
    # seat for the separate prop bracket (1.0 deep recess + 2 pilot holes for M2x4 self-tapping screws)
    xp = G.X_HINGE + PROP_DX
    for s in (-1, 1):
        ya_, yb_ = sorted((G.YC + s * BR_IN, G.YC + s * BR_OUT))
        body = body - prism(box(xp - BR_X / 2 - 0.2, ya_ - 0.2, xp + BR_X / 2 + 0.2, yb_ + 0.2), Z['fb'] - 0.1, Z['fb'] + 1.0)
    for s in (-1, 1):
        body = body - cyl_z(xp, G.YC + s * BR_SCREW, 0.85, Z['fb'], Z['fb'] + 2.6)
    return body

PROP_DX, PROP_W, EAR_H, PIVOT_DZ = 95.0, 74.0, 6.0, -3.0
BR_X, BR_T, BR_SCREW = 10.0, 2.0, 44.0
BR_IN, BR_OUT = PROP_W / 2 + 0.6, PROP_W / 2 + 10.0      # each bracket spans y from ear inner face to beyond its screw

def prop_bracket():
    """separate pivot bracket, modelled in the page's flat frame (glue-free: 2x M2x4 self-tapping into the page floor)"""
    xp = G.X_HINGE + PROP_DX
    zt = Z['fb'] + 1.0                       # top of bracket sits in the recess
    b = None
    for s in (-1, 1):
        ya_, yb_ = sorted((G.YC + s * BR_IN, G.YC + s * BR_OUT))
        pl = Pos(xp, -(ya_ + yb_) / 2, zt - BR_T / 2) * Box(BR_X, yb_ - ya_, BR_T)
        b = pl if b is None else b + pl
    for s in (-1, 1):
        yy = G.YC + s * (PROP_W / 2 + 0.6 + 2.0)
        b = b + Pos(xp, -yy, (zt - BR_T + Z['fb'] - EAR_H) / 2 + 0.3) * Box(BR_X, 4, (zt - BR_T) - (Z['fb'] - EAR_H) + 0.6)
        b = b - cyl_z(xp, G.YC + s * BR_SCREW, 1.15, zt - BR_T - 1, zt + 1)
        b = b - cyl_z(xp, G.YC + s * BR_SCREW, 2.1, zt - BR_T - 1, zt - BR_T + 0.8)
    b = b - cyl_y(xp, G.YC - PROP_W / 2 - 8, G.YC + PROP_W / 2 + 8, Z['fb'] + PIVOT_DZ, 1.65)
    return b

# knuckle layout along KiCad y (page owns these, spine owns the gaps); TRRS window left free
y0, y1 = G.PAGE_Y
KNUCKLES_PAGE = [(y0, y0 + 16), (y0 + 52, y0 + 66), (y1 - 16, y1)]
KNUCKLES_SPINE = [(y0 + 16.4, y0 + 36), (y0 + 66.4, y0 + 74)]
PROP_DX, PROP_W, EAR_H, PIVOT_DZ = 95.0, 74.0, 6.0, -3.0   # pivot 95 mm from hinge, 7 mm below hinge axis

# ------------------------------------------------------------------ top cover
def top_cover():
    skirt = prism(G.OUTER_W.difference(G.SKIRT_IN), Z['pcbT'] + 0.02, Z['cB'] + 0.3)
    holes = unary_union([G.sq(x, y, a, G.SW_HOLE) for x, y, a in G.KEYS] +
                        [G.ENCODER.buffer(0.3, join_style=2)] + [Point(x, y).buffer(1.15, 24) for x, y in G.HOLES])
    plate = prism(G.OUTER_W.difference(G.NOTCH).difference(holes), Z['cB'], Z['cT'])
    keep = unary_union([G.sq(x, y, a, G.KEEP) for x, y, a in G.KEYS] + [G.ENCODER.buffer(1.0, join_style=2), G.NOTCH.buffer(1.0)])
    web_area = G.OUTER_W.buffer(-1.2).difference(keep)
    web = prism(web_area, Z['cT'] - 0.3, Z['web'])
    cover = skirt + plate + web
    for x, y in G.HOLES:                                      # counterbore for the M2 heads
        cover = cover - cyl_z(x, y, 2.25, Z['cT'] + 0.2, Z['web'] + 0.1)
        cover = cover - cyl_z(x, y, 1.15, Z['cB'] - 0.1, Z['web'] + 0.1)
    cover = cover - prism(G.TRRS_SLOT, Z['pcbB'], Z['web'] + 2)
    return cover

if __name__ == '__main__':
    out = sys.argv[1]
    bc = bottom_case(); tc = top_cover()
    print('bottom vol', round(bc.volume), 'cover vol', round(tc.volume))
    pb = prop_bracket()
    export_stl(pb, f'{out}/prop_bracket.stl', tolerance=0.02, angular_tolerance=0.2); export_step(pb, f'{out}/prop_bracket.step')
    for name, p in (('R_bottom_case', bc), ('R_top_cover', tc)):
        export_stl(p, f'{out}/{name}.stl', tolerance=0.02, angular_tolerance=0.2)
        export_step(p, f'{out}/{name}.step')
    for name, p in (('L_bottom_case', bc), ('L_top_cover', tc)):
        m = mirror(p, Plane.YZ)
        export_stl(m, f'{out}/{name}.stl', tolerance=0.02, angular_tolerance=0.2)
        export_step(m, f'{out}/{name}.step')
    print('done')
