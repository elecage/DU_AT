from collections import namedtuple

EvalResult = namedtuple('EvalResult', ['value', 'name', 'is_percentage', 'is_bigger_better'])
